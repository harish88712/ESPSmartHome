.. _scd4x:

scd4x - Driver for SCD40/SCD41 miniature CO₂ sensor
===================================================

.. doxygengroup:: scd4x
   :members:


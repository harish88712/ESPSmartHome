.. _mhz19b:

mhz19b - Driver for MH-Z19B NDIR CO₂ sensor connected to UART
=============================================================

.. doxygengroup:: mhz19b
   :members:

.. _sfa3x:

sfa3x - Driver for SFA30 formaldehyde detection module (I2C)
============================================================

.. doxygengroup:: sfa3x
   :members:

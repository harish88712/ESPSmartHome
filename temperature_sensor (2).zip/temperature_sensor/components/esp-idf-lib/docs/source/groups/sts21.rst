.. _sts21:

sts21 - Driver for Driver for STS21 temperature sensor
======================================================

.. doxygengroup:: sts21
   :members:


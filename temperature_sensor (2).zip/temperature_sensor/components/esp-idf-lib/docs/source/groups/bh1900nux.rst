.. _bh1900nux:

bh1900nux - Driver for BH1900NUX temperature sensor
===================================================

.. doxygengroup:: bh1900nux
   :members:


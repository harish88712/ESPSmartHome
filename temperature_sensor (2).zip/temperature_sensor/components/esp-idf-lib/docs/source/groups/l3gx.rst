.. _l3gx:

l3gx - Driver for L3Gx(L3GD20/L3G4200D) 3-axis gyroscope sensors
================================================================

.. doxygengroup:: l3gx
   :members:

